"use strict";
(() => {
  // extension/src/popup.ts
  var DEFAULT_API_URL = "https://crumbsbypixel.vercel.app";
  var activeToken = null;
  var apiUrl = DEFAULT_API_URL;
  var currentTab = null;
  var selectedImage = null;
  var candidateImages = [];
  var viewUnauth = document.getElementById("view-unauthenticated");
  var viewCapture = document.getElementById("view-capture");
  var btnConnect = document.getElementById("btn-connect");
  var btnManualToken = document.getElementById("btn-manual-token");
  var btnSettings = document.getElementById("btn-settings");
  var candidateGrid = document.getElementById("candidate-grid");
  var inputTitle = document.getElementById("input-title");
  var btnSave = document.getElementById("btn-save");
  var btnSaveText = document.getElementById("btn-save-text");
  var statusContainer = document.getElementById("status-container");
  async function init() {
    const sync = await chrome.storage.sync.get(["crumbs_token", "crumbs_api_url"]);
    activeToken = sync.crumbs_token || null;
    apiUrl = (sync.crumbs_api_url || DEFAULT_API_URL).replace(/\/$/, "");
    btnSettings.addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
    btnManualToken.addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
    btnConnect.addEventListener("click", () => {
      chrome.tabs.create({ url: `${apiUrl}/connect?ext_id=${chrome.runtime.id}` });
      window.close();
    });
    if (!activeToken) {
      viewUnauth.classList.remove("hidden");
      viewCapture.classList.add("hidden");
      return;
    }
    viewUnauth.classList.add("hidden");
    viewCapture.classList.remove("hidden");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tab || null;
    if (!tab || !tab.id || !tab.url) {
      showStatus("error", "Cannot capture from this browser view.");
      return;
    }
    chrome.tabs.sendMessage(tab.id, { type: "EXTRACT_PAGE_DATA" }, (response) => {
      if (chrome.runtime.lastError || !response) {
        handleExtractedData({
          product_url: tab.url,
          page_title: tab.title || "",
          image_candidates: [],
          selected_image_url: null
        });
      } else {
        handleExtractedData(response);
      }
    });
    btnSave.addEventListener("click", handleSave);
  }
  function handleExtractedData(data) {
    inputTitle.value = data.page_title || "";
    candidateImages = data.image_candidates.slice(0, 6);
    selectedImage = data.selected_image_url || (candidateImages.length > 0 ? candidateImages[0] : null);
    renderCandidates();
  }
  function renderCandidates() {
    candidateGrid.innerHTML = "";
    if (candidateImages.length === 0) {
      const emptyMsg = document.createElement("div");
      emptyMsg.style.gridColumn = "1 / -1";
      emptyMsg.style.padding = "16px";
      emptyMsg.style.textAlign = "center";
      emptyMsg.style.color = "#736f68";
      emptyMsg.style.fontSize = "12px";
      emptyMsg.textContent = "No product images detected. Our server will scrape the best image on save.";
      candidateGrid.appendChild(emptyMsg);
      return;
    }
    candidateImages.forEach((imgUrl) => {
      const item = document.createElement("div");
      item.className = "candidate-item" + (imgUrl === selectedImage ? " selected" : "");
      const img = document.createElement("img");
      img.src = imgUrl;
      img.loading = "lazy";
      item.appendChild(img);
      if (imgUrl === selectedImage) {
        const badge = document.createElement("div");
        badge.className = "selected-badge";
        badge.innerHTML = "\u2713";
        item.appendChild(badge);
      }
      item.addEventListener("click", () => {
        selectedImage = imgUrl;
        renderCandidates();
      });
      candidateGrid.appendChild(item);
    });
  }
  async function handleSave() {
    if (!activeToken || !currentTab?.url) return;
    btnSave.disabled = true;
    btnSaveText.textContent = "Saving...";
    statusContainer.classList.add("hidden");
    try {
      const res = await fetch(`${apiUrl}/api/capture`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${activeToken}`
        },
        body: JSON.stringify({
          product_url: currentTab.url,
          page_title: inputTitle.value.trim() || currentTab.title || void 0,
          selected_image_url: selectedImage || void 0,
          image_candidates: candidateImages
        })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to save piece");
      }
      showStatus(
        "success",
        data.deduplicated ? "Already saved on your board!" : "\u2713 Saved to crumbs!",
        true
      );
      btnSaveText.textContent = "Saved";
    } catch (err) {
      showStatus("error", err instanceof Error ? err.message : "Failed to capture piece");
      btnSave.disabled = false;
      btnSaveText.textContent = "Save piece";
    }
  }
  function showStatus(type, message, showLink = false) {
    statusContainer.className = `status-badge ${type}`;
    statusContainer.innerHTML = "";
    const msgSpan = document.createElement("span");
    msgSpan.textContent = message;
    statusContainer.appendChild(msgSpan);
    if (showLink) {
      const link = document.createElement("a");
      link.className = "view-link";
      link.textContent = "View your board \u2192";
      link.href = "#";
      link.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: apiUrl });
        window.close();
      });
      statusContainer.appendChild(link);
    }
    statusContainer.classList.remove("hidden");
  }
  document.addEventListener("DOMContentLoaded", init);
})();
